/*
 ============================================================================
 Name        : server_esonero.c
 Author      : Alessia De Feudis
 Version     : 22/11/2024
 Copyright   : Your copyright notice
 Description : creazione server
 ============================================================================
 */

#include "server.h" // Header for shared constants and macros

// This function creates a numeric password using only digits (0-9).
void generate_numeric(char *password, int length) {
    if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Enforce maximum length
    for (int i = 0; i < length; i++) {
        password[i] = '0' + rand() % 10; // Randomly pick a digit
    }
    password[length] = '\0'; // Append a null character to terminate the string
}

// This function generates an alphabetic password consisting of lowercase letters.
void generate_alpha(char *password, int length) {
    if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Ensure password length is within bounds
    for (int i = 0; i < length; i++) {
        password[i] = 'a' + rand() % 26; // Randomly pick a letter from 'a' to 'z'
    }
    password[length] = '\0'; // End the string with a null character
}

// This function creates a mixed password with both numbers and letters.
void generate_mixed(char *password, int length) {
    if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Cap the length of the password
    for (int i = 0; i < length; i++) {
        if (rand() % 2 == 0) {
            password[i] = '0' + rand() % 10; // Add a digit
        } else {
            password[i] = 'a' + rand() % 26; // Add a letter
        }
    }
    password[length] = '\0'; // Properly terminate the string
}

// This function generates a secure password with letters, numbers, and special characters.
void generate_secure(char *password, int length) {
    if (length > MAX_PASSWORD_LENGTH) length = MAX_PASSWORD_LENGTH; // Respect the maximum allowed length
    const char charset[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
    int charset_size = sizeof(charset) - 1; // Calculate number of usable characters
    for (int i = 0; i < length; i++) {
        password[i] = charset[rand() % charset_size]; // Randomly select a character from the set
    }
    password[length] = '\0'; // Ensure the string is null-terminated
}

int main(void) {
    #if defined WIN32
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != 0) {
        fprintf(stderr, "Winsock initialization failed.\n");
        return -1;
    }
    #endif

    printf("Server starting on port %d...\n", PROTOPORT);

    // Create a TCP server socket
    int server_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (server_socket < 0) {
        perror("Failed to create socket");
        clearwinsock();
        return -1;
    }

    // Define server address and bind it to the socket
    struct sockaddr_in sad;
    memset(&sad, 0, sizeof(sad));
    sad.sin_family = AF_INET;
    sad.sin_addr.s_addr = INADDR_ANY;
    sad.sin_port = htons(PROTOPORT);
    if (bind(server_socket, (struct sockaddr *)&sad, sizeof(sad)) < 0) {
        perror("Binding failed");
        closesocket(server_socket);
        clearwinsock();
        return -1;
    }


    // Start listening for incoming connections
    if (listen(server_socket, 5) < 0) {
        perror("Failed to listen on the socket");
        closesocket(server_socket);
        clearwinsock();
        return -1;
    }
    printf("Server is up and waiting for client connections.\n");

    srand((unsigned)time(NULL)); // Initialize random seed for password generation

    while (1) {
        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);

        // Accept a new client connection
        int client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &client_len);
        if (client_socket < 0) {
            perror("Error while accepting connection");
            continue;
        }
        printf("Connected to client %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        char buffer[BUFFERSIZE];
        int bytes_received;

        // Process client requests
        while ((bytes_received = recv(client_socket, buffer, BUFFERSIZE - 1, 0)) > 0) {
            buffer[bytes_received] = '\0'; // Ensure the string is null-terminated
            printf("Received request: '%s'\n", buffer);

            if (strcmp(buffer, "q") == 0) {
                printf("Client requested to terminate the session.\n");
                break;
            }

            char type;
            int length;

            // Validate input format
            if (sscanf(buffer, "%c %d", &type, &length) != 2) {
                const char *error_msg = "Invalid format. Use: <type> <length>\n";
                send(client_socket, error_msg, strlen(error_msg), 0);
                continue;
            }

            // Validate password length
            if (length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
                const char *error_msg = "Invalid length. Choose between 6 and 32 characters.\n";
                send(client_socket, error_msg, strlen(error_msg), 0);
                continue;
            }

            char password[MAX_PASSWORD_LENGTH + 1];

            // Generate the appropriate password based on the type
            switch (type) {
                case 'n':
                    generate_numeric(password, length);
                    break;
                case 'a':
                    generate_alpha(password, length);
                    break;
                case 'm':
                    generate_mixed(password, length);
                    break;
                case 's':
                    generate_secure(password, length);
                    break;
                default:
                    send(client_socket, "Invalid type. Use n, a, m, or s.\n", 41, 0);
                    continue;
            }

            // Send the generated password back to the client
            printf("Generated password: %s\n", password);
            send(client_socket, password, strlen(password), 0);
        }

        // Close the connection with the client
        closesocket(client_socket);
        printf("Client connection closed.\n");
    }

    // Cleanup resources and close the server socket
    closesocket(server_socket);
    clearwinsock();
    return 0;
}
