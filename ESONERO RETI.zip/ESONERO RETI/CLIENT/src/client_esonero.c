/*
 ============================================================================
 Name        : client_esonero.c
 Author      : Alessia De Feudis
 Version     : 22/11/2024
 Copyright   : Your copyright notice
 Description : creazione client
 ============================================================================
 */
#include "client.h"  // Include shared definitions and prototypes

// Function to handle errors by printing an error message to stderr
void errorhandler(const char *error_message) {
    fprintf(stderr, "%s\n", error_message);
}

// Main client function
int main(void) {
    // Ensure standard output is not buffered
    setbuf(stdout, NULL);

    // Windows-specific: Initialize Winsock library
    #if defined WIN32
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != 0) {
        fprintf(stderr, "Error initializing Winsock.\n");
        return -1;
    }
    #endif

    // Create a client socket using the TCP protocol (SOCK_STREAM)
    int c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (c_socket < 0) {
        errorhandler("Socket creation failed.");
        #if defined WIN32
        clearwinsock();
        #endif
        return -1;
    }

    // Define server address details
    struct sockaddr_in sad;                  // Structure to store server details
    memset(&sad, 0, sizeof(sad));            // Clear memory for safety
    sad.sin_family = AF_INET;                // Address family: Internet (IPv4)
    sad.sin_addr.s_addr = inet_addr("127.0.0.1"); // Localhost IP address
    sad.sin_port = htons(PROTOPORT);         // Server port, converted to network byte order

    // Connect to the server using the specified address and port
    if (connect(c_socket, (struct sockaddr *)&sad, sizeof(sad)) < 0) {
        errorhandler("Connection to server failed.");
        closesocket(c_socket);
        #if defined WIN32
        clearwinsock();
        #endif
        return -1;
    }

    printf("Successfully connected to the server.\n");

    char request[BUFFERSIZE];  // Buffer for client requests
    char response[BUFFERSIZE]; // Buffer for server responses
    int password_length;       // Variable to store requested password length

    // Main loop: Send requests to the server and process responses
    while (1) {
        // Improved user prompt with options for different types of passwords
        printf("Enter the password type and length (e.g., 'n 8' for numeric 8-character password, 'm' for mixed, 's' for secure, 'a' for alphabetic), or 'q' to quit: ");
        fgets(request, BUFFERSIZE, stdin); // Read input from the user

        // Remove trailing newline character from input
        request[strcspn(request, "\n")] = 0;

        // Check if the user wants to quit
        if (strcmp(request, "q") == 0) {
            printf("Exiting the program... Closing connection.\n");
            break;
        }

        // Validate input format (minimum length: type + space + length)
        if (strlen(request) < 3) {
            printf("Invalid input. Please enter the password type and length in the format: <type> <length>\n");
            continue;
        }

        // Extract the password length and validate its range
        if (sscanf(request + 2, "%d", &password_length) != 1 ||
            password_length < MIN_PASSWORD_LENGTH ||
            password_length > MAX_PASSWORD_LENGTH) {
            printf("Invalid password length. The length must be between %d and %d characters.\n",
                   MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH);
            continue;
        }

        // Send the request to the server
        if (send(c_socket, request, strlen(request), 0) < 0) {
            errorhandler("Failed to send data to server.");
            break;
        }

        // Receive the generated password from the server
        int bytes_rcvd = recv(c_socket, response, BUFFERSIZE - 1, 0);
        if (bytes_rcvd <= 0) {
            errorhandler("Failed to receive data from server.");
            break;
        }

        // Null-terminate the received data to ensure it's a valid string
        response[bytes_rcvd] = '\0';

        // Print the generated password to the user
        if (request[0] == 'n') {
            printf("Generated numeric password: %s\n", response);
        } else if (request[0] == 'm') {
            printf("Generated mixed password (letters and numbers): %s\n", response);
        } else if (request[0] == 's') {
            printf("Generated secure password (letters, numbers, and symbols): %s\n", response);
        } else if (request[0] == 'a') {
            printf("Generated alphabetic password (letters only): %s\n", response);
        } else {
            printf("Invalid password type requested.\n");
        }
    }

    // Close the socket to terminate the connection
    closesocket(c_socket);

    // Windows-specific: Clean up Winsock resources
    #if defined WIN32
    clearwinsock();
    #endif

    return 0;
}
