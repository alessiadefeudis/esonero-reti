/*
 * client.h
 *
 *  Created on: 20 nov 2024
 *      Author: Alessia
 */

#ifndef COMMON_H
#define COMMON_H

#include <stdio.h>      // Standard I/O functions (e.g., printf, scanf)
#include <stdlib.h>     // Standard library functions (e.g., malloc, free, rand)
#include <string.h>     // String manipulation functions (e.g., strcpy, strcmp, strlen)
#include <time.h>       // Time-related functions for random number generation (e.g., time, srand)

#if defined(WIN32)
#include <winsock2.h>   // Windows-specific socket library for network communication
#include <ws2tcpip.h>   // Windows-specific TCP/IP functions (e.g., inet_pton, inet_ntoa)
#define closesocket(s) closesocket(s)  // Redefine closesocket to close the socket on Windows
#else
#include <sys/socket.h> // General socket library for UNIX-like operating systems (e.g., Linux, macOS)
#include <arpa/inet.h>  // Functions for manipulating internet addresses (e.g., inet_pton, htons)
#include <unistd.h>     // UNIX-specific functions (e.g., read, write, close)
#define closesocket(s) close(s)        // Redefine closesocket to close the socket on UNIX systems
#define clearwinsock()  // No-op for UNIX systems; cleanup not required here
#endif

// Constants for server communication and password generation
#define PROTOPORT 27015              // Default port for server-client communication (for listening)
#define BUFFERSIZE 1024              // Maximum buffer size for receiving and sending data over the network
#define MIN_PASSWORD_LENGTH 6        // Minimum valid password length (used for validation)
#define MAX_PASSWORD_LENGTH 32       // Maximum valid password length (used for validation)

// Function prototypes for different password generation types
void generate_numeric(char *password, int length);  // Function to generate numeric passwords
void generate_alpha(char *password, int length);    // Function to generate alphabetic passwords (lowercase only)
void generate_mixed(char *password, int length);    // Function to generate mixed passwords (numeric and alphabetic)
void generate_secure(char *password, int length);   // Function to generate secure passwords (including special characters)

// Windows-specific function for cleaning up Winsock resources
#if defined(WIN32)
void clearwinsock() {
    WSACleanup();  // Clean up and close any opened Winsock resources in Windows
}
#endif // WIN32

#endif // COMMON_H
